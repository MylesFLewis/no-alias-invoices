from copy import deepcopy
from pathlib import Path
from datetime import date
from decimal import Decimal
import tempfile, subprocess, os, io
from urllib.request import urlopen
from urllib.parse import urlparse, unquote
from PIL import Image
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx import Document
from docx.table import _Row, _Cell

BASE = Path(__file__).resolve().parent
MAX_LOGO_BYTES = 10 * 1024 * 1024

def text(p, value):
    # Retain the paragraph and first run's formatting.
    if p.runs:
        p.runs[0].text = value
        for run in p.runs[1:]: run.text = ''
    else: p.add_run(value)

def cell(c, value):
    text(c.paragraphs[0], value)
    for p in c.paragraphs[1:]: text(p, '')

def uk(value): return date.fromisoformat(value).strftime('%d/%m/%Y')
def money(pence): return f'£{Decimal(pence)/100:,.2f}'


def company_logo(document):
    source = os.getenv('COMPANY_LOGO', '').strip()
    if not source:
        return  # Keep the template's existing logo.
    try:
        parsed = urlparse(source)
        if parsed.scheme in ('http', 'https'):
            with urlopen(source, timeout=10) as response:
                raw = response.read(MAX_LOGO_BYTES + 1)
        elif parsed.scheme in ('', 'file'):
            if parsed.scheme == 'file' and parsed.netloc not in ('', 'localhost'):
                raise ValueError('Use a local file path or HTTP(S) URL for Company logo.')
            path = Path(unquote(parsed.path) if parsed.scheme else source)
            with path.open('rb') as stream:
                raw = stream.read(MAX_LOGO_BYTES + 1)
        else:
            raise ValueError('Company logo must be a file path or HTTP(S) URL.')
        if len(raw) > MAX_LOGO_BYTES:
            raise ValueError('Company logo must be at most 10 MB.')
        with Image.open(io.BytesIO(raw)) as image:
            if image.format not in ('PNG', 'JPEG'):
                raise ValueError('Company logo must be a PNG or JPEG image.')
            if image.width * image.height > 20_000_000:
                raise ValueError('Company logo has too many pixels (maximum 20 million).')
            image.load()
            output = io.BytesIO()
            image.convert('RGBA').save(output, format='PNG')
            width, height = image.size
        parts = [document.part]
        for section in document.sections:
            parts.extend((section.header.part, section.footer.part))
        replaced = False
        for part in dict.fromkeys(parts):
            # Replace the existing drawing without changing its position.
            blips = part.element.xpath('.//a:blip')
            for blip in blips:
                rid, _ = part.get_or_add_image(io.BytesIO(output.getvalue()))
                blip.set(qn('r:embed'), rid)
                blip.attrib.pop(qn('r:link'), None)
                drawing = next((node for node in blip.iterancestors() if node.tag == qn('w:drawing')), None)
                if drawing is not None:
                    extents = drawing.xpath('.//wp:extent')
                    if extents:
                        maxw, maxh = int(extents[0].get('cx')), int(extents[0].get('cy'))
                        scale = min(maxw / width, maxh / height)
                        for extent in extents + drawing.xpath('.//a:xfrm/a:ext'):
                            extent.set('cx', str(int(width * scale)))
                            extent.set('cy', str(int(height * scale)))
                replaced = True
        if not replaced:
            # Match the original template's floating logo at the upper left.
            # Anchoring keeps the business text and invoice tables in place.
            scale = min(2325375 / width, 2200940 / height)
            shape = document.paragraphs[0].add_run().add_picture(
                io.BytesIO(output.getvalue()), width=int(width * scale), height=int(height * scale))
            inline = shape._inline
            anchor = OxmlElement('wp:anchor')
            for key, value in {'distT':'0','distB':'0','distL':'114300','distR':'114300',
                               'simplePos':'0','relativeHeight':'251658240','behindDoc':'0',
                               'locked':'0','layoutInCell':'1','allowOverlap':'1'}.items():
                anchor.set(key, value)
            simple = OxmlElement('wp:simplePos'); simple.set('x','0'); simple.set('y','0'); anchor.append(simple)
            for axis, relative, offset in [('H','column','-478466'),('V','paragraph','-457200')]:
                position = OxmlElement('wp:position'+axis); position.set('relativeFrom',relative)
                value = OxmlElement('wp:posOffset'); value.text=offset; position.append(value); anchor.append(position)
            anchor.append(inline.find(qn('wp:extent')))
            anchor.append(OxmlElement('wp:wrapNone'))
            for tag in ('wp:docPr','wp:cNvGraphicFramePr','a:graphic'):
                anchor.append(inline.find(qn(tag)))
            inline.getparent().replace(inline, anchor)
    except ValueError:
        raise
    except Exception as error:
        raise ValueError('Unable to load Company logo. Use a readable PNG/JPEG path inside the container or an accessible HTTP(S) URL.') from error

def service_columns(table, document):
    count=len(table.columns)
    if count not in (4,5,6):raise ValueError('The service template must have four, five or six columns.')
    grid=table._tbl.tblGrid
    # Preserve merged title and totals cells while upgrading older templates.
    for index in ([1,4] if count==4 else [4] if count==5 else []):
        old_count=len(grid)
        grid.insert(index,deepcopy(grid[0]))
        for row in table.rows:
            cells=row._tr.tc_lst
            if len(cells)==old_count:
                added=deepcopy(cells[index-1]);cells[index-1].addnext(added);cell(_Cell(added,table),'')
            else:
                for element in cells:
                    if element.grid_span>1:element.tcPr.gridSpan.val=element.grid_span+1
    section=document.sections[0]
    available=int((section.page_width-section.left_margin-section.right_margin)/635)
    total=min(sum(int(column.get(qn('w:w'))) for column in grid),available)
    widths=[round(total*fraction) for fraction in (.15,.13,.22,.20,.18)]
    widths.append(total-sum(widths))
    table.autofit=False
    props=table._tbl.tblPr
    tw=props.find(qn('w:tblW'));tw.set(qn('w:type'),'dxa');tw.set(qn('w:w'),str(total))
    indent=props.find(qn('w:tblInd'))
    if indent is not None:indent.set(qn('w:w'),'0')
    for column,width in zip(grid,widths):column.set(qn('w:w'),str(width))
    for row in table.rows:
        for height in row._tr.get_or_add_trPr().findall(qn('w:trHeight')):
            height.set(qn('w:hRule'),'atLeast')
        offset=0
        for element in row._tr.tc_lst:
            span=element.grid_span
            element.tcPr.tcW.w=sum(widths[offset:offset+span]);offset+=span
            for tag in ('noWrap','tcFitText'):
                for item in element.tcPr.findall(qn('w:'+tag)):element.tcPr.remove(item)
            for paragraph in element.xpath('.//w:p'):
                pp=paragraph.get_or_add_pPr()
                wrap=pp.find(qn('w:wordWrap'))
                if wrap is None:wrap=OxmlElement('w:wordWrap');pp.append(wrap)
                wrap.set(qn('w:val'),'1')
    cell(table.rows[1].cells[1], 'Work order number')
    cell(table.rows[1].cells[4], 'Other details')

def generate(data, settings, number):
    private_template = Path(os.getenv('DATA_DIR','/data')) / 'invoice-template.docx'
    d = Document(private_template if private_template.exists() else BASE / 'templates/invoice.docx')
    # Keep references before removing any optional paragraphs.
    business_paragraphs = list(d.paragraphs[:6])
    terms_paragraph = d.paragraphs[13]
    date_paragraph = d.paragraphs[12]
    terms = settings['terms']
    days = data.get('payment_term_days')
    if days is not None:
        terms = 'Payment due on the invoice date.' if days == 0 else f'Payment due within {days} calendar days of the invoice date.'
    recipient_paragraph = d.paragraphs[7]
    sender_ppr = deepcopy(business_paragraphs[0]._p.pPr)
    sender_run = next((run for run in business_paragraphs[0].runs if run._r.xpath('.//w:t')), None)
    sender_rpr = deepcopy(sender_run._r.rPr) if sender_run is not None else None
    # Paragraph positions match both the original and sanitized template.
    for i,key in enumerate(('name','business','address','phone','email','website')):
        p=d.paragraphs[i]
        nodes=p._p.xpath('.//w:t')
        if nodes:
            nodes[0].text=settings[key]
            for n in nodes[1:]: n.text=''
        else: text(p,settings[key])
    recipient = 'Invoice to: ' + data['customer']
    for key in ('customer_contact_name', 'customer_address', 'customer_email'):
        value = data.get(key, '').strip()
        if value:
            recipient += '\n' + value
    text(d.paragraphs[7], recipient)
    text(d.paragraphs[12], 'Date of invoice: ' + uk(data['date']))
    text(terms_paragraph, 'Payment terms: ' + terms if terms.strip() else '')
    for i,key in ((4,'email'),(5,'website')):
        for link in d.paragraphs[i]._p.xpath('.//w:hyperlink'):
            rid=link.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            if rid in d.part.rels:
                value=settings[key]
                d.part.rels[rid]._target=('mailto:'+value if key=='email' else (value if value.startswith(('http://','https://')) else 'https://'+value)) if value else ''
    business = os.getenv('BUSINESS_NAME', '').strip()
    if business:
        text(d.paragraphs[1], business)
    company_logo(d)
    # ISO dates sort chronologically; Python's stable sort retains same-day order.
    lines = sorted(data['lines'], key=lambda line: date.fromisoformat(line['date']))
    table = d.tables[0]
    service_columns(table,d)
    # Clone a formatted service row, then replace the six template placeholders.
    prototype = deepcopy(table.rows[2]._tr)
    deposit_row, total_row = table.rows[8], table.rows[9]
    for row in list(table.rows)[2:8]:
        table._tbl.remove(row._tr)
    for line in lines:
        row_xml = deepcopy(prototype)
        deposit_row._tr.addprevious(row_xml)
        row = _Row(row_xml, table)
        properties = row_xml.get_or_add_trPr()
        for item in properties.findall(qn('w:cantSplit')):properties.remove(item)
        values = [uk(line['date']), line.get('work_order_number',''), line['venue'], line['service'], line.get('other_details',''), money(line['fee'])]
        for c, v in zip(row.cells, values):
            cell(c, v)
    for row in list(table.rows)[:2]:
        properties = row._tr.get_or_add_trPr()
        if properties.find(qn('w:tblHeader')) is None:
            properties.append(OxmlElement('w:tblHeader'))
    cell(deposit_row.cells[-1], money(data['deposit']))
    cell(total_row.cells[-1], money(sum(x['fee'] for x in data['lines'])-data['deposit']))
    cell(d.tables[1].rows[0].cells[1], number)
    bank = d.tables[2]
    bank_rows = list(bank.rows)
    bank_values = [settings['account_name'], settings['account_number'], settings['sort_code']]
    for row, label, value in zip(bank_rows[1:], ['Account Name', 'Account Number', 'Sort Code'], bank_values):
        if value.strip():
            cell(row.cells[0], label); cell(row.cells[1], value)
        else:
            bank._tbl.remove(row._tr)
    if not any(value.strip() for value in bank_values):
        bank._tbl.getparent().remove(bank._tbl)
    for paragraph, key in zip(business_paragraphs, ('name','business','address','phone','email','website')):
        value = business if key == 'business' and business else settings[key]
        if not value.strip():
            if paragraph._p.xpath('.//w:drawing'):
                # Retain the logo's anchor without reserving a blank text line.
                paragraph.paragraph_format.space_before = Pt(0)
                paragraph.paragraph_format.space_after = Pt(0)
                paragraph.paragraph_format.line_spacing = Pt(1)
            else:
                paragraph._p.getparent().remove(paragraph._p)
    # Use the same paragraph and text formatting as the sender details.
    previous = recipient_paragraph._p
    for index, value in enumerate(recipient.split('\n')):
        paragraph = recipient_paragraph if index == 0 else type(recipient_paragraph)(OxmlElement('w:p'), recipient_paragraph._parent)
        if index:
            previous.addnext(paragraph._p)
        paragraph._p.clear_content()
        existing = paragraph._p.pPr
        if existing is not None:paragraph._p.remove(existing)
        if sender_ppr is not None:paragraph._p.insert(0,deepcopy(sender_ppr))
        run = paragraph.add_run(value)
        if sender_rpr is not None:
            run._r.insert(0,deepcopy(sender_rpr))
        previous = paragraph._p
    # Keep the service table below floating logos as the text block shrinks.
    for wrap in d.part.element.xpath('.//wp:anchor/wp:wrapNone'):
        replacement = OxmlElement('wp:wrapSquare')
        replacement.set('wrapText', 'bothSides')
        wrap.getparent().replace(wrap, replacement)
    if data.get('due_date'):
        due = type(date_paragraph)(OxmlElement('w:p'), date_paragraph._parent)
        date_paragraph._p.addnext(due._p)
        if date_paragraph._p.pPr is not None:due._p.insert(0,deepcopy(date_paragraph._p.pPr))
        run = due.add_run('Date due: ' + uk(data['due_date']))
        if date_paragraph.runs and date_paragraph.runs[0]._r.rPr is not None:
            run._r.insert(0,deepcopy(date_paragraph.runs[0]._r.rPr))
    if not terms.strip():
        terms_paragraph._p.getparent().remove(terms_paragraph._p)
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp); source=root/'invoice.docx'; d.save(source)
        command = [os.getenv('SOFFICE','soffice'), f'-env:UserInstallation={ (root/"profile").as_uri() }', '--headless', '--convert-to', 'pdf', '--outdir', str(root), str(source)]
        result=subprocess.run(command,capture_output=True,timeout=90)
        pdf=root/'invoice.pdf'
        if result.returncode or not pdf.exists(): raise RuntimeError('PDF conversion failed. Check the container logs.')
        return pdf.read_bytes()
