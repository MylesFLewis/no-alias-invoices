from pathlib import Path
from datetime import date
from decimal import Decimal
import tempfile, subprocess, os
from docx import Document

BASE = Path(__file__).resolve().parent

def text(p, value):
    # Retain the paragraph and first run's formatting.
    if p.runs:
        p.runs[0].text = value
        for run in p.runs[1:]: run.text = ''
    else: p.add_run(value)

def cell(c, value):
    text(c.paragraphs[0], value)
    for p in c.paragraphs[1:]: text(p, '')

def uk(value): return date.fromisoformat(value).strftime('%d/%m/%Y')
def money(pence): return f'£{Decimal(pence)/100:,.2f}'

def generate(data, settings, number):
    private_template = Path(os.getenv('DATA_DIR','/data')) / 'invoice-template.docx'
    d = Document(private_template if private_template.exists() else BASE / 'templates/invoice.docx')
    # Paragraph positions match both the original and sanitized template.
    for i,key in enumerate(('name','business','address','phone','email','website')):
        p=d.paragraphs[i]
        nodes=p._p.xpath('.//w:t')
        if nodes:
            nodes[0].text=settings[key]
            for n in nodes[1:]: n.text=''
        else: text(p,settings[key])
    text(d.paragraphs[7], 'Invoice to: ' + data['customer'])
    text(d.paragraphs[12], 'Date of invoice: ' + uk(data['date']))
    text(d.paragraphs[13], 'Payment terms: ' + settings['terms'])
    for i,key in ((4,'email'),(5,'website')):
        for link in d.paragraphs[i]._p.xpath('.//w:hyperlink'):
            rid=link.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
            if rid in d.part.rels:
                value=settings[key]
                d.part.rels[rid]._target=('mailto:'+value if key=='email' else (value if value.startswith(('http://','https://')) else 'https://'+value)) if value else ''
    table = d.tables[0]
    for i in range(6):
        values = ['', '', '', '']
        if i < len(data['lines']):
            line = data['lines'][i]
            values = [uk(line['date']), line['venue'], line['service'], money(line['fee'])]
        for c,v in zip(table.rows[i+2].cells, values): cell(c,v)
    cell(table.rows[8].cells[-1], money(data['deposit']))
    cell(table.rows[9].cells[-1], money(sum(x['fee'] for x in data['lines'])-data['deposit']))
    cell(d.tables[1].rows[0].cells[1], number)
    bank = d.tables[2]
    for row, label, value in [(1,'Account Name',settings['account_name']), (2,'Account Number',settings['account_number']), (3,'Sort Code',settings['sort_code'])]:
        cell(bank.rows[row].cells[0],label); cell(bank.rows[row].cells[1],value)
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp); source=root/'invoice.docx'; d.save(source)
        command = [os.getenv('SOFFICE','soffice'), f'-env:UserInstallation={ (root/"profile").as_uri() }', '--headless', '--convert-to', 'pdf', '--outdir', str(root), str(source)]
        result=subprocess.run(command,capture_output=True,timeout=90)
        pdf=root/'invoice.pdf'
        if result.returncode or not pdf.exists(): raise RuntimeError('PDF conversion failed. Check the container logs.')
        return pdf.read_bytes()
